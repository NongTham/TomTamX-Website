_G.config = {
    team = "Marines", -- can be Pirates or Marines!
    minplayerserver = true, -- means if you want to join to a clear server or a max server
    usewebhook = false, -- if you want to use discord webhook
    webhook = "PUT-WEBHOOK-HERE"
}

loadstring(game:HttpGet("https://raw.githubusercontent.com/ZexcaTDEV/hydrahub/refs/heads/main/fruitfinder", true))()